<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="ko_KR">
<context>
    <name>ChatServer</name>
    <message>
        <location filename="chatserver.ui" line="16"/>
        <source>Chatting Server</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="chatserver.ui" line="29"/>
        <source>Client List</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="chatserver.ui" line="46"/>
        <source>Status</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="chatserver.ui" line="51"/>
        <location filename="chatserver.ui" line="88"/>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="chatserver.ui" line="73"/>
        <source>IP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="chatserver.ui" line="78"/>
        <source>Port</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="chatserver.ui" line="83"/>
        <source>ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="chatserver.ui" line="93"/>
        <source>Message</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="chatserver.ui" line="98"/>
        <source>Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="chatserver.ui" line="108"/>
        <source>Clear</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="chatserver.ui" line="115"/>
        <source>Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="chatserver.cpp" line="32"/>
        <source>Echo Server</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="chatserver.cpp" line="33"/>
        <source>Unable to start the server: %1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="chatserver.cpp" line="39"/>
        <source>&amp;Invite</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="chatserver.cpp" line="43"/>
        <source>&amp;Kick out</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="chatserver.cpp" line="51"/>
        <source>The server is running on port %1.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ClientManagerForm</name>
    <message>
        <location filename="clientmanagerform.ui" line="19"/>
        <source>Client Info</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="clientmanagerform.ui" line="41"/>
        <source>&amp;Input</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="clientmanagerform.ui" line="51"/>
        <source>I&amp;D</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="clientmanagerform.ui" line="68"/>
        <source>&amp;Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="clientmanagerform.ui" line="81"/>
        <source>&amp;Phone Number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="clientmanagerform.ui" line="94"/>
        <source>&amp;Address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="clientmanagerform.ui" line="124"/>
        <source>&amp;Add</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="clientmanagerform.ui" line="131"/>
        <source>&amp;Modify</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="clientmanagerform.ui" line="138"/>
        <source>&amp;Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="clientmanagerform.ui" line="158"/>
        <source>&amp;Search</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="clientmanagerform.ui" line="168"/>
        <location filename="clientmanagerform.ui" line="194"/>
        <location filename="clientmanagerform.ui" line="235"/>
        <source>ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="clientmanagerform.ui" line="173"/>
        <location filename="clientmanagerform.ui" line="199"/>
        <location filename="clientmanagerform.ui" line="240"/>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="clientmanagerform.ui" line="178"/>
        <location filename="clientmanagerform.ui" line="204"/>
        <location filename="clientmanagerform.ui" line="245"/>
        <source>Phone Number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="clientmanagerform.ui" line="183"/>
        <location filename="clientmanagerform.ui" line="209"/>
        <location filename="clientmanagerform.ui" line="250"/>
        <source>Address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="clientmanagerform.ui" line="222"/>
        <source>S&amp;earch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="clientmanagerform.cpp" line="18"/>
        <source>&amp;Remove</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="mainwindow.ui" line="14"/>
        <source>MainWindow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="44"/>
        <source>&amp;File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="54"/>
        <source>toolBar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="71"/>
        <source>Quit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="76"/>
        <location filename="mainwindow.cpp" line="16"/>
        <source>Client Info</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="79"/>
        <source>Ctrl+1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="84"/>
        <location filename="mainwindow.cpp" line="23"/>
        <source>Product Info</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="87"/>
        <source>Ctrl+2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="92"/>
        <location filename="mainwindow.ui" line="95"/>
        <location filename="mainwindow.cpp" line="29"/>
        <source>Order Info</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="98"/>
        <source>Ctrl+3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="103"/>
        <location filename="mainwindow.ui" line="106"/>
        <source>Server Info</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="109"/>
        <source>Ctrl+4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="33"/>
        <source>ChatServer Info</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>OrderManagerForm</name>
    <message>
        <location filename="ordermanagerform.ui" line="16"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ordermanagerform.ui" line="39"/>
        <location filename="ordermanagerform.ui" line="46"/>
        <source>--Client Select--</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ordermanagerform.ui" line="51"/>
        <source>CID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ordermanagerform.ui" line="56"/>
        <location filename="ordermanagerform.ui" line="358"/>
        <source>ClientName</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ordermanagerform.ui" line="97"/>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ordermanagerform.ui" line="102"/>
        <source>Phone Number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ordermanagerform.ui" line="107"/>
        <source>Address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ordermanagerform.ui" line="130"/>
        <location filename="ordermanagerform.ui" line="137"/>
        <source>--Product Select--</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ordermanagerform.ui" line="142"/>
        <source>PID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ordermanagerform.ui" line="147"/>
        <location filename="ordermanagerform.ui" line="363"/>
        <source>ProductName</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ordermanagerform.ui" line="169"/>
        <source>Product Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ordermanagerform.ui" line="174"/>
        <source>Price</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ordermanagerform.ui" line="179"/>
        <source>Stock</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ordermanagerform.ui" line="191"/>
        <source>OID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ordermanagerform.ui" line="211"/>
        <source>&amp;ClientName</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ordermanagerform.ui" line="228"/>
        <source>&amp;ProductName</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ordermanagerform.ui" line="245"/>
        <source>&amp;Stock</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ordermanagerform.ui" line="262"/>
        <source>&amp;Amount</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ordermanagerform.ui" line="285"/>
        <source>&amp;TotalPrice</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ordermanagerform.ui" line="319"/>
        <source>&amp;Add</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ordermanagerform.ui" line="326"/>
        <source>&amp;Modify</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ordermanagerform.ui" line="333"/>
        <source>&amp;Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ordermanagerform.ui" line="368"/>
        <source>Amount</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ordermanagerform.ui" line="373"/>
        <source>TotalPrice</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ordermanagerform.ui" line="378"/>
        <source>Date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ordermanagerform.cpp" line="18"/>
        <source>&amp;Remove</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ProductManagerForm</name>
    <message>
        <location filename="productmanagerform.ui" line="16"/>
        <source>Client Info</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="productmanagerform.ui" line="38"/>
        <source>&amp;Input</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="productmanagerform.ui" line="48"/>
        <source>&amp;PID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="productmanagerform.ui" line="65"/>
        <source>&amp;ProductName</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="productmanagerform.ui" line="78"/>
        <source>&amp;Price</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="productmanagerform.ui" line="91"/>
        <source>&amp;Stock</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="productmanagerform.ui" line="121"/>
        <source>&amp;Add</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="productmanagerform.ui" line="128"/>
        <source>&amp;Modify</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="productmanagerform.ui" line="135"/>
        <source>&amp;Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="productmanagerform.ui" line="155"/>
        <source>&amp;Search</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="productmanagerform.ui" line="165"/>
        <location filename="productmanagerform.ui" line="191"/>
        <location filename="productmanagerform.ui" line="232"/>
        <source>PID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="productmanagerform.ui" line="170"/>
        <location filename="productmanagerform.ui" line="196"/>
        <location filename="productmanagerform.ui" line="237"/>
        <source>ProductName</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="productmanagerform.ui" line="175"/>
        <location filename="productmanagerform.ui" line="201"/>
        <location filename="productmanagerform.ui" line="242"/>
        <source>Price</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="productmanagerform.ui" line="180"/>
        <location filename="productmanagerform.ui" line="206"/>
        <location filename="productmanagerform.ui" line="247"/>
        <source>Stock</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="productmanagerform.ui" line="219"/>
        <source>S&amp;earch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="productmanagerform.cpp" line="18"/>
        <source>&amp;Remove</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
